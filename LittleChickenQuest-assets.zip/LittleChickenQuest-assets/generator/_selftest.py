import sys
sys.path.insert(0, '/home/claude/chicken-assets/generator')
from lib import *
a = Asset('selftest')
gold = mat('gold', '#E0A030', metal=0.0, emissive='#FFB830', emissive_strength=0.5)
red = mat('red', '#C2573A')
green = mat('green', '#6E8A3A')
a.add(lathe([(0.5,0),(0.6,0.5),(0.2,1.0),(0.0,1.2)], 14), gold)
a.add(blade(1.2, 0.3, 0.03, 8, 'leaf', zfun=lambda t: 0.3*t*t), green, T=M((1.2,0,0)))
a.add(torus(0.6, 0.06), red, T=M((0,1.4,0)))
a.add(box((0.4,0.4,0.4)), red, T=M((-1.2,0.2,0)), flat=True)
a.add(segment((0,0,0),(0.5,1.0,0.3),0.03), green, T=M((0,0,1.2)))
a.add(lumpy(0.5, seed=3), red, T=M((0,0.3,-1.3)), flat=True)
print('bytes', a.export('/home/claude/chicken-assets/previews/_selftest.glb'), 'tris', a.stats())
import trimesh
s = trimesh.load('/home/claude/chicken-assets/previews/_selftest.glb', force='scene')
print(list(s.geometry.keys()))
print(s.bounds)
# check normals outward on lathe & torus
l = lathe([(0.5,0),(0.6,0.5),(0.2,1.0),(0.0,1.2)], 14)
tri = l.triangles_center - l.centroid
print('lathe outward frac', (np.einsum('ij,ij->i', l.face_normals, tri) > 0).mean())
t = torus(0.6, 0.06)
cen = np.array([0.6*t.triangles_center[:,0]/np.hypot(t.triangles_center[:,0], t.triangles_center[:,2]), np.zeros(len(t.faces)), 0.6*t.triangles_center[:,2]/np.hypot(t.triangles_center[:,0], t.triangles_center[:,2])]).T
print('torus outward frac', (np.einsum('ij,ij->i', t.face_normals, t.triangles_center-cen) > 0).mean())
