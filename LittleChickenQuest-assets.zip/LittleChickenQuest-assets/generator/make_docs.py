"""Writes ../docs/ASSETS_GUIDE.md and ../docs/PROMPT_FOR_REVOLTE.md from manifest.json."""
import json, os
HERE = os.path.dirname(os.path.abspath(__file__))
man = json.load(open(os.path.join(HERE, '..', 'manifest.json')))
os.makedirs(os.path.join(HERE, '..', 'docs'), exist_ok=True)

WHAT = {
    'chicken': ('Hero: tiny round chicken with teal shoulder bag', 'Animate nodes: wing_L, wing_R (flap: rotation.z), leg_L, leg_R (walk: rotation.x), head (bob: rotation.x), tail, body. Faces +Z.'),
    'feather_gold': ('Collectible glowing golden feather', 'Node glow = soft halo (hide it with glow.visible=false). Spin it with rotation.y and bob it up and down.'),
    'eagle_flying': ('Living eagle for the rescue swoop (about 8 m wingspan)', 'Flap wing_L / wing_R with rotation.z (pivots are at the shoulders). tail and talons are separate nodes.'),
    'eagle_statue': ('The giant stone eagle statue on its hilltop (the big reveal)', 'Nodes: base, body, head, wing_L, wing_R, claw. Origin on the ground. Face +Z. Chicken is about 70 times smaller: scale the statue down ~0.4 or the chicken up for framing.'),
    'lotus_chariot': ('Golden lotus flying chariot, no wheels', 'Origin = centre of the seat cushion (place the chicken at 0,0,0). Nodes: base, seat, posts, canopy, cloth, lanterns. For the storm break-up, push each node apart. Suggested game scale 0.5.'),
    'hut_village': ('Kerala-style village house with tiled roof and veranda', 'Front (veranda, door) faces +Z. One lit brass lamp. Origin = centre of footprint on the ground.'),
    'temple': ('Small temple with tiered tower and glowing doorway', 'Front faces +Z. Use it far in the background (scale 1 to 3).'),
    'palm_tree': ('Coconut palm', 'Nodes: trunk, crown. Sway the crown with a tiny rotation.z for wind.'),
    'hibiscus': ('Hibiscus bush with red flowers', 'Scatter along path edges. Scale 1.5 for a bolder bush.'),
    'banana_plant': ('Banana plant', 'Scatter near huts.'),
    'ground_red_earth': ('Red-earth ground tile 8 x 8 m', 'Top surface at y=0. Tile it in a grid for the village path.'),
    'paddy_field': ('Green paddy tile 8 x 8 m with rice rows', 'Top near y=-0.05. Tile to the side of the path.'),
    'stone_steps': ('Mossy stone steps climbing toward -Z', 'Nine steps, 0.28 m rise each. Origin at the bottom front step.'),
    'rock_a': ('Small mossy rock', 'Scatter as obstacles or decoration. Reuse with random scale and rotation.'),
    'rock_b': ('Large mossy rock', 'Scale 3 to 8 to build the broken cliff edge.'),
    'puddle': ('Shiny puddle', 'Obstacle for the village run. Sits on the ground at y=0.'),
    'vine': ('Hanging forest vine', 'Hangs down from its origin. Reuse many times.'),
    'cloud': ('Soft cloud', 'Scale 2 to 6 and scatter for the sky ride.'),
}

rows = []
for k, v in man.items():
    d, n = WHAT.get(k, (k, ''))
    rows.append(f"| `{k}.glb` | {d} | {v['size_m'][0]} x {v['size_m'][1]} x {v['size_m'][2]} | {v['triangles']:,} | {n} |")
table = '\n'.join(rows)
total_tris = sum(v['triangles'] for v in man.values())

guide = f"""# Little Chicken Quest: 3D assets guide

{len(man)} low-poly `.glb` models, all generated in code (no textures, no downloads, original designs).
Total: {total_tris:,} triangles, about {sum(v['kb'] for v in man.values()) / 1024:.1f} MB. Verified: every file passes the official Khronos glTF validator with zero errors
and loads in three.js `GLTFLoader`.

## Conventions
- **Y is up, +Z is the front** of every model, **units are metres**.
- Colours are flat PBR materials with stable names (for example `chicken_cream`). No textures, no UVs.
- Models with moving parts are split into **named nodes** whose origin is the joint, so you can rotate them in code.
- Folder layout: `assets/models/*.glb`, `assets/previews/*.png`, `generator/` (Python that rebuilt every file), `manifest.json`.

## Models
| File | What it is | Size (W x H x D, m) | Triangles | Notes and nodes |
|---|---|---|---|---|
{table}

Full list of nodes (with pivots) and every material (with hex colour) is in `manifest.json`.

## Load in three.js
```js
import * as THREE from 'three';
import {{ GLTFLoader }} from 'three/examples/jsm/loaders/GLTFLoader.js';

const loader = new GLTFLoader();
const load = async (name) => (await loader.loadAsync(`/assets/models/${{name}}.glb`)).scene;

const chicken = await load('chicken');
chicken.traverse(o => {{ if (o.isMesh) {{ o.castShadow = true; o.receiveShadow = true; }} }});
scene.add(chicken);

// animate by node name (call every frame, t = seconds)
const wingL = chicken.getObjectByName('wing_L'), wingR = chicken.getObjectByName('wing_R');
const legL = chicken.getObjectByName('leg_L'), legR = chicken.getObjectByName('leg_R');
function waddle(t, speed) {{
  legL.rotation.x =  Math.sin(t * 10) * 0.6 * speed;
  legR.rotation.x = -Math.sin(t * 10) * 0.6 * speed;
  chicken.rotation.z = Math.sin(t * 10) * 0.06 * speed;
}}
function flap(t) {{ wingL.rotation.z = -0.3 - Math.abs(Math.sin(t * 18)) * 0.9; wingR.rotation.z = 0.3 + Math.abs(Math.sin(t * 18)) * 0.9; }}
```

**Recolour by material name** (palette is also in `generator/palette.py`):
```js
model.traverse(o => {{ if (o.isMesh && o.material.name === 'chicken_cream') o.material.color.set('#F6E3B0'); }});
```
Materials are shared inside one loaded model. Use `material.clone()` if you want two variants.

**Lighting that suits these models:** one warm directional light low in the sky (golden dawn, colour `#FFC98A`, intensity 2.5), a soft hemisphere light (sky `#F3C7D8`, ground `#6E8A3A`, intensity 0.9), shadows on, fog colour `#C9B8C8` so far objects fade into mist. Tone mapping ACESFilmic. Glowing parts (feather, lanterns, temple door) already carry an emissive colour.

## Performance
- Whole pack is about {total_tris / 1000:.0f}k triangles, so a scene using 10 palms, 8 rocks, 2 huts, 1 temple and the chicken stays well under 150k triangles.
- Reuse with `model.clone()`. For rocks, vines and grass use `THREE.InstancedMesh` on the mesh inside the model.
- `eagle_statue.glb` is the heaviest ({man['eagle_statue']['triangles']:,} triangles). Only load it for the summit scene.

## Using your painted images as a backdrop
The 7 painted images are flat, so they work as a **sky and distant-hills backdrop**, with the 3D models in front.
```js
const tex = new THREE.TextureLoader().load('/backdrops/05_statue.png'); // the painting
tex.colorSpace = THREE.SRGBColorSpace;
const bg = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({{ map: tex, fog: false, depthWrite: false }}));
bg.renderOrder = -1000; scene.add(bg);
const fwd = new THREE.Vector3();
function updateBackdrop() {{            // call every frame, after moving the camera
  const dist = camera.far * 0.9;
  camera.getWorldDirection(fwd);
  bg.position.copy(camera.position).addScaledVector(fwd, dist);
  bg.quaternion.copy(camera.quaternion);
  const h = 2 * Math.tan(THREE.MathUtils.degToRad(camera.fov / 2)) * dist * 1.1;
  bg.scale.set(h * camera.aspect, h, 1);
}}
```
Limits: it cannot be walked into, and it does not change when the player turns. Keep the camera mostly facing the painting
(limit yaw to about 35 degrees) or shift `tex.offset.x` slightly with yaw for a parallax feel. Make the foreground ground colour match the painting.

## Scene recipes (what to place in each of the 7 screens)
1. **Dawn village:** 3 x 2 `ground_red_earth` tiles as the path, 2 `hut_village` on the left, 6 `palm_tree`, `hibiscus` and `banana_plant` along the edges, `paddy_field` tiles on the right, `temple` far away (scale 2) in mist, 2 `puddle`, chicken at the start.
2. **Stone path:** `stone_steps` x 2 end to end climbing away, `rock_a` and `hibiscus` on the sides, 3 `feather_gold` floating 0.6 m above the steps, a few palms below the hill.
3. **Broken cliff:** two big `rock_b` (scale 6) with a 6 m gap, `lotus_chariot` (scale 0.5) drifting in toward the gap, chicken at the edge.
4. **Chariot ride:** `lotus_chariot` with the chicken at its origin, 10 to 15 `cloud` (scale 3 to 6) moving past, nothing else.
5. **Summit reveal:** `eagle_statue` (scale 0.4), `lotus_chariot` parked on the left, chicken in front, `rock_b` scattered around.
6. **Ending:** chicken in front of the statue's claw, `feather_gold` x 3 laid at its feet, then the golden sky burst and the text "For my little one."
7. **Close-up:** camera very close to the chicken's face, same scene.
**Storm and rescue (between 4 and 5):** darken the lights, then `eagle_flying` swoops in from the side (scale 1), flapping, and carries the chicken to the summit.

## Regenerate or tweak
```
cd generator
python3 -m pip install trimesh numpy pillow
python3 build_all.py            # rebuilds every model
python3 build_all.py chicken    # rebuilds one model
python3 make_manifest.py
```
Change a hex in `generator/palette.py` and rebuild to recolour a whole family of models.
Previews in `assets/previews/` come from a simple software renderer: the real look in three.js (with lights and shadows) will be richer.

## Respect
The eagle statue is an original tribute design. Keep the tone respectful, and keep it free of jokes, ads and game-over screens.
"""
open(os.path.join(HERE, '..', 'docs', 'ASSETS_GUIDE.md'), 'w').write(guide)

prompt = f"""PROJECT
Build "Little Chicken Quest": a short explorable 3D web game for phones and laptops (three.js, WebGL2, plain JavaScript, Vite or a single index.html). It must open from a link, run well on a mid-range phone, and have a clean, large, high-contrast HTML/CSS user interface.

READ FIRST (in this repo)
- docs/ASSETS_GUIDE.md : conventions, how to load, animation node names, scene recipes, backdrop code.
- manifest.json : every model, its size, nodes and materials.
- assets/models/*.glb : {len(man)} ready-made low-poly models. USE THESE. Do NOT generate your own models, shapes or sprites for anything they cover. Copy assets/ to public/assets/ if the build needs it.
- The 7 painted images in the repo root (01 ... 07 *.png): use them only as flat BACKDROPS behind the 3D (sky and far hills), as described in the guide. Copy them to public/backdrops/ and rename to simple names (01_village.png, and so on). Do not use them as textures on models.

STORY (respectful tribute, original designs)
A tiny chicken with a teal shoulder bag goes to see a giant stone eagle statue (Jatayu). Tagline at the end: "For my little one."

CONTROLS
Third-person camera behind the chicken. WASD / arrows to walk, Space to jump, mouse drag to look. On phones: a left on-screen joystick, a jump button and a "cluck" button (the chicken hops and flaps). The chicken must use the model's nodes: waddle with leg_L / leg_R, flap with wing_L / wing_R.

SCENES, IN ORDER (recipes in the guide)
1. Dawn village: walk the red-earth path. Collect nothing yet. Short intro text.
2. Stone path uphill: collect 3 floating golden feathers (feather_gold). Show a feather counter (0/3).
3. Broken cliff: when 3 feathers are collected, the lotus chariot drifts in. Walk to it and press E / tap to board.
4. Chariot ride (about 20 s automatic): fly over clouds. Storm darkens the sky. Lightning, the chariot breaks apart (move its nodes apart), the chicken falls in slow motion.
5. Rescue and summit reveal: eagle_flying swoops in, catches the chicken, sets it down at the summit. Reveal the giant eagle_statue at sunrise with a slow camera pull-back. This is the key shot: make it dramatic.
6. Ending: the chicken places the 3 feathers at the statue's claw and bows. The sky bursts into golden light. Fade in "For my little one." Buttons: Replay, Share (Web Share API, else copy link).

LOOK
Golden dawn: one warm low directional light (#FFC98A), pink-lavender hemisphere light, soft shadows, fog colour #C9B8C8 for mist, ACES tone mapping, floating golden sparkles. Backdrop planes show the matching painting behind each scene.

PERFORMANCE
Target 60 fps on a mid-range phone. Keep draw calls low, reuse models with clone(), use InstancedMesh for rocks, pixel ratio capped at 2, add a ?quality=low switch (no shadows, pixel ratio 1, fewer clouds and palms).

RULES
- Original designs only. Nothing copied from any film.
- Treat Jatayu respectfully: no jokes, no ads, no game-over screen with him.
- No external model, texture or audio downloads. Sound optional (mute by default).
- Put all colours, speeds and scene lengths in one CONFIG object at the top.

BUILD ORDER
1. Load the chicken in scene 1 with controls and the backdrop. Run the live preview and give me the link.
2. Scene 5 (summit with statue and the painted backdrop). Give me the link.
3. Then scenes 2, 3, 4 and 6, one at a time.
"""
open(os.path.join(HERE, '..', 'docs', 'PROMPT_FOR_REVOLTE.md'), 'w').write(prompt)
print('docs written')
