PROJECT
Build "Little Chicken Quest": a short explorable 3D web game for phones and laptops (three.js, WebGL2, plain JavaScript, Vite or a single index.html). It must open from a link, run well on a mid-range phone, and have a clean, large, high-contrast HTML/CSS user interface.

READ FIRST (in this repo)
- docs/ASSETS_GUIDE.md : conventions, how to load, animation node names, scene recipes, backdrop code.
- manifest.json : every model, its size, nodes and materials.
- assets/models/*.glb : 18 ready-made low-poly models. USE THESE. Do NOT generate your own models, shapes or sprites for anything they cover. Copy assets/ to public/assets/ if the build needs it.
- The 7 painted images in the repo root (01 ... 07 *.png): use them only as flat BACKDROPS behind the 3D (sky and far hills), as described in the guide. Copy them to public/backdrops/ and rename to simple names (01_village.png, and so on). Do not use them as textures on models.

STORY (respectful tribute, original designs)
A tiny chicken with a teal shoulder bag goes to see a giant stone eagle statue (Jatayu). Tagline at the end: "For my little one."

CONTROLS
Third-person camera behind the chicken. WASD / arrows to walk, Space to jump, mouse drag to look. On phones: a left on-screen joystick, a jump button and a "cluck" button (the chicken hops and flaps). The chicken must use the model's nodes: waddle with leg_L / leg_R, flap with wing_L / wing_R.

SCENES, IN ORDER (recipes in the guide)
1. Dawn village: walk the red-earth path. Collect nothing yet. Short intro text.
2. Stone path uphill: collect 3 floating golden feathers (feather_gold). Show a feather counter (0/3).
3. Broken cliff: when 3 feathers are collected, the lotus chariot drifts in. Walk to it and press E / tap to board.
4. Chariot ride (about 20 s automatic): fly over clouds. Storm darkens the sky. Lightning, the chariot breaks apart (move its nodes apart), the chicken falls in slow motion.
5. Rescue and summit reveal: eagle_flying swoops in, catches the chicken, sets it down at the summit. Reveal the giant eagle_statue at sunrise with a slow camera pull-back. This is the key shot: make it dramatic.
6. Ending: the chicken places the 3 feathers at the statue's claw and bows. The sky bursts into golden light. Fade in "For my little one." Buttons: Replay, Share (Web Share API, else copy link).

LOOK
Golden dawn: one warm low directional light (#FFC98A), pink-lavender hemisphere light, soft shadows, fog colour #C9B8C8 for mist, ACES tone mapping, floating golden sparkles. Backdrop planes show the matching painting behind each scene.

PERFORMANCE
Target 60 fps on a mid-range phone. Keep draw calls low, reuse models with clone(), use InstancedMesh for rocks, pixel ratio capped at 2, add a ?quality=low switch (no shadows, pixel ratio 1, fewer clouds and palms).

RULES
- Original designs only. Nothing copied from any film.
- Treat Jatayu respectfully: no jokes, no ads, no game-over screen with him.
- No external model, texture or audio downloads. Sound optional (mute by default).
- Put all colours, speeds and scene lengths in one CONFIG object at the top.

BUILD ORDER
1. Load the chicken in scene 1 with controls and the backdrop. Run the live preview and give me the link.
2. Scene 5 (summit with statue and the painted backdrop). Give me the link.
3. Then scenes 2, 3, 4 and 6, one at a time.
