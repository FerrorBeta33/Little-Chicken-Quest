"""Software preview renderer (no GPU needed): draws GLB files as flat-shaded PNGs for a quick visual check."""
import math
import sys
import numpy as np
import trimesh
from PIL import Image, ImageDraw


def render(path, out, size=720, yaw=35, pitch=22, bg=(236, 222, 205), ss=2):
    scene = trimesh.load(path, force='scene')
    meshes = scene.dump(concatenate=False)
    allv = np.vstack([m.vertices for m in meshes])
    lo, hi = allv.min(0), allv.max(0)
    centre = (lo + hi) / 2
    radius = np.linalg.norm(hi - lo) / 2

    ya, pa = math.radians(yaw), math.radians(pitch)
    Ry = np.array([[math.cos(ya), 0, math.sin(ya)], [0, 1, 0], [-math.sin(ya), 0, math.cos(ya)]])
    Rx = np.array([[1, 0, 0], [0, math.cos(pa), -math.sin(pa)], [0, math.sin(pa), math.cos(pa)]])
    R = Rx @ Ry
    light = np.array([-0.5, 0.8, 0.6])
    light /= np.linalg.norm(light)

    polys = []
    for m in meshes:
        mat = getattr(m.visual, 'material', None)
        base = np.array([200, 200, 200], float)
        emis = np.zeros(3)
        def to_srgb(lin):
            lin = np.clip(np.array(lin, float), 0, 1)
            return 255 * np.where(lin <= 0.0031308, 12.92 * lin, 1.055 * np.power(lin, 1 / 2.4) - 0.055)
        if mat is not None:
            bc = getattr(mat, 'baseColorFactor', None)
            if bc is not None:
                base = to_srgb(np.array(bc[:3], float) / 255.0)
            ef = getattr(mat, 'emissiveFactor', None)
            if ef is not None:
                emis = to_srgb(ef[:3])
        # split big triangles so the painter's-algorithm sort stays correct (preview only)
        try:
            sv, sf = trimesh.remesh.subdivide_to_size(m.vertices, m.faces, max_edge=radius * 0.09, max_iter=6)
        except Exception:
            sv, sf = m.vertices, m.faces
        v = (sv - centre) @ R.T
        tri = v[sf]
        n = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
        ln = np.linalg.norm(n, axis=1, keepdims=True)
        n = n / np.maximum(ln, 1e-12)
        # normals in view space; light fixed in view space
        diff = np.abs(n @ light)
        shade = 0.38 + 0.62 * diff
        col = np.clip(base[None, :] * shade[:, None] + emis[None, :], 0, 255)
        depth = tri[:, :, 2].mean(axis=1)
        alpha = 1.0
        if mat is not None and getattr(mat, 'alphaMode', None) == 'BLEND':
            bc = getattr(mat, 'baseColorFactor', None)
            alpha = float(bc[3]) / 255.0 if bc is not None else 0.3
        for k in range(len(tri)):
            polys.append((depth[k] + (1000 if alpha < 1.0 else 0), tri[k], col[k], alpha))
    polys.sort(key=lambda t: t[0])  # far (small z) first

    W = size * ss
    img = Image.new('RGB', (W, W), bg)
    d = ImageDraw.Draw(img)
    scale = W * 0.46 / radius
    overlay = Image.new('RGBA', (W, W), (0, 0, 0, 0))
    od = ImageDraw.Draw(overlay)
    for _, tri, col, alpha in polys:
        pts = [(W / 2 + p[0] * scale, W / 2 - p[1] * scale) for p in tri]
        if alpha < 1.0:
            od.polygon(pts, fill=tuple(int(c) for c in col) + (int(255 * max(0.12, alpha)),))
        else:
            d.polygon(pts, fill=tuple(int(c) for c in col))
    img = Image.alpha_composite(img.convert('RGBA'), overlay).convert('RGB')
    img = img.resize((size, size), Image.LANCZOS)
    img.save(out)


def sheet(paths, out, cols=3, size=520, labels=None):
    tiles = []
    for i, p in enumerate(paths):
        tmp = out + f'.tmp{i}.png'
        render(p, tmp, size=size)
        tiles.append(Image.open(tmp))
    rows = math.ceil(len(tiles) / cols)
    S = Image.new('RGB', (cols * size, rows * size), (236, 222, 205))
    for i, t in enumerate(tiles):
        S.paste(t, ((i % cols) * size, (i // cols) * size))
    d = ImageDraw.Draw(S)
    if labels:
        for i, lab in enumerate(labels):
            d.text(((i % cols) * size + 10, (i // cols) * size + 8), lab, fill=(60, 40, 30))
    S.save(out)
    import os
    for i in range(len(tiles)):
        os.remove(out + f'.tmp{i}.png')


if __name__ == '__main__':
    render(sys.argv[1], sys.argv[2], yaw=float(sys.argv[3]) if len(sys.argv) > 3 else 35,
           pitch=float(sys.argv[4]) if len(sys.argv) > 4 else 22)
