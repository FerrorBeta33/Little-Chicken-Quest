"""Builds every model into ../models/*.glb and renders quick previews into ../previews/.
Usage:  python3 build_all.py [name ...]      (no names = build everything)"""
import os
import sys
import importlib

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
OUT = os.path.join(HERE, '..', 'models')
PRE = os.path.join(HERE, '..', 'previews')
os.makedirs(OUT, exist_ok=True)
os.makedirs(PRE, exist_ok=True)

REGISTRY = []   # (file name, callable, preview yaw, pitch)


def register():
    import a_hero as H
    REGISTRY.extend([
        ('chicken', H.chicken, 28, 14),
        ('feather_gold', H.feather_gold, 20, 8),
        ('rock_a', lambda: H.rock(11, 0.9), 35, 20),
        ('rock_b', lambda: H.rock(23, 1.8), 55, 20),
        ('cloud', H.cloud, 25, 10),
        ('puddle', H.puddle, 25, 40),
        ('vine', H.vine, 30, 8),
    ])
    for mod, entries in (('a_nature', 'ENTRIES'), ('a_buildings', 'ENTRIES'), ('a_big', 'ENTRIES')):
        try:
            m = importlib.import_module(mod)
        except ModuleNotFoundError:
            continue
        REGISTRY.extend(getattr(m, entries))


if __name__ == '__main__':
    register()
    want = set(sys.argv[1:])
    import preview
    for name, fn, yaw, pitch in REGISTRY:
        if want and name not in want:
            continue
        asset = fn()
        path = os.path.join(OUT, f'{name}.glb')
        size = asset.export(path)
        preview.render(path, os.path.join(PRE, f'{name}.png'), yaw=yaw, pitch=pitch)
        print(f'{name:22s} {asset.stats():7d} tris  {size / 1024:7.1f} KB')
