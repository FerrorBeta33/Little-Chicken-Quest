"""All colours in one place. Change a hex here, re-run build_all.py, and every model updates.
(Or recolour at runtime in three.js by material name: mesh.material.color.set('#...').)"""
from lib import mat

# ---- chicken
CHICKEN_CREAM = '#F6E3B0'
CHICKEN_AMBER = '#E0A640'     # wings, tail
CHICKEN_COMB = '#D83A2B'
CHICKEN_BEAK = '#E8923A'
CHICKEN_LEG = '#E8A838'
CHICKEN_EYE = '#2A1A12'
BAG_TEAL = '#3F6F63'
BAG_TEAL_DARK = '#2F5A50'

# ---- gold
GOLD_LIGHT = '#FFD86A'
GOLD_MID = '#E0A030'
GOLD_DARK = '#A0601E'
CUSHION_RED = '#B8282E'
CLOTH_CREAM = '#FFF1D6'

# ---- earth, rock, plants
EARTH_LIGHT = '#C2573A'
EARTH_MID = '#8F3A2A'
EARTH_DARK = '#5A2A25'
ROCK_LIGHT = '#C9936A'
ROCK_MID = '#8A6048'
ROCK_DARK = '#4E3A34'
MOSS = '#7F8F3A'
LEAF_LIGHT = '#B9C25A'
LEAF_MID = '#6E8A3A'
LEAF_DARK = '#2F4A2A'
BARK_LIGHT = '#8A6A47'
BARK_DARK = '#5E4430'
HIBISCUS_RED = '#D8262B'
STAMEN = '#F2C230'
COCONUT = '#8C9A3C'

# ---- buildings
WALL_WHITE = '#F3E9D8'
ROOF_TILE_A = '#B5472E'
ROOF_TILE_B = '#9C3A25'
WOOD_DARK = '#5A3A26'
WOOD_MID = '#7A5238'
TEMPLE_CREAM = '#E8D3A8'
TEMPLE_OCHRE = '#C9935A'
TEMPLE_RED = '#B5472E'
CLAY_POT = '#9B5A3A'

# ---- statue stone
STONE_LIGHT = '#E8C9A0'
STONE_MID = '#B89574'
STONE_DARK = '#6E5545'

# ---- living eagle (rescue)
EAGLE_BROWN = '#6B4A32'
EAGLE_GOLD = '#D9A441'
EAGLE_CREAM = '#F0DDB5'

# ---- sky / mist
CLOUD_LIGHT = '#F6E6EE'
CLOUD_SHADE = '#C9B8C8'
STORM = '#4A4358'
WATER_GOLD = '#E3B070'
