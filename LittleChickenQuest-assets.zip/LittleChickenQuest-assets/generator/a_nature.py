"""Plants and ground: coconut palm, hibiscus bush, banana plant, red-earth tile, paddy tile."""
import math
import numpy as np
import trimesh
from lib import *
import palette as P


def _frond(a, part, mats, FT, L, width, leaflets=9, rise=0.32, droop=0.8, leaflet_len=0.95, leaflet_w=0.1):
    """Palm frond in local space (length along +Y, droops toward local +Z), placed by FT."""
    rachis_m, leaf_a, leaf_b = mats
    zf = lambda t, L=L, rise=rise, droop=droop: L * (droop * t * t - rise * t) * 0.5
    a.add(blade(L, 0.05, 0.02, 9, 'leaf', zfun=zf), rachis_m, part, FT)
    for k in range(leaflets):
        t = 0.16 + 0.78 * k / max(1, leaflets - 1)
        ln = leaflet_len * (1.0 - 0.55 * t)
        for side, th in ((0, -64), (1, 64)):
            lz = lambda u, ln=ln: 0.3 * ln * u * u
            T = FT @ M((0, t * L, zf(t))) @ M(rot=(0, 0, th))
            a.add(blade(ln, leaflet_w, 0.008, 4, 'leaf', zfun=lz), leaf_a if (k + side) % 2 else leaf_b, part, T, flat=True)


def palm_tree():
    """Coconut palm, ~6.6 m tall, trunk leans slightly toward +X. Nodes: trunk, crown (fronds + coconuts)."""
    a = Asset('palm_tree')
    bark_a = mat('palm_bark_light', P.BARK_LIGHT, rough=1.0)
    bark_b = mat('palm_bark_dark', P.BARK_DARK, rough=1.0)
    rachis = mat('palm_rachis', P.LEAF_DARK, rough=0.9)
    la = mat('palm_leaf_light', P.LEAF_LIGHT, rough=0.9)
    lb = mat('palm_leaf_mid', P.LEAF_MID, rough=0.9)
    nut = mat('palm_coconut', P.COCONUT, rough=0.8)
    H, lean, n = 6.4, 0.9, 16
    cx = lambda s: lean * s ** 1.7
    rad = lambda s: 0.26 - 0.12 * s + (0.1 * (1 - s) ** 6)
    a.part('trunk')
    for i in range(n):
        s0, s1 = i / n, (i + 1) / n
        seg = lathe([(rad(s0), s0 * H, cx(s0), 0), (rad(s1) * 1.04, s1 * H, cx(s1), 0)], 10)
        a.add(seg, bark_a if i % 2 == 0 else bark_b, 'trunk')
    top = np.array([cx(1.0), H, 0.0])
    a.part('crown', top)
    nf = 11
    for i in range(nf):
        az = i * 360.0 / nf + (7 if i % 2 else -5)
        rise = 0.45 if i % 3 == 0 else 0.22
        Lf = 3.3 + 0.5 * ((i * 5) % 3) * 0.5
        FT = M(top + np.array([0, 0.05, 0]), rot=(90, az, 0))
        _frond(a, 'crown', (rachis, la, lb), FT, Lf, 0.05, 9, rise, 0.85 + 0.1 * (i % 2))
    for k, ang in enumerate((0, 120, 240)):
        r = 0.2
        a.add(sphere(0.12, 2), nut, 'crown', M(top + np.array([r * math.cos(math.radians(ang)), -0.12, r * math.sin(math.radians(ang))])))
    return a


def hibiscus():
    """Hibiscus bush with red flowers, ~0.8 m tall and wide (scale it up 1.5x for a bolder foreground bush)."""
    a = Asset('hibiscus')
    leaf_d = mat('hibiscus_leaf_dark', P.LEAF_DARK, rough=0.9)
    leaf_m = mat('hibiscus_leaf', P.LEAF_MID, rough=0.9)
    leaf_l = mat('hibiscus_leaf_light', P.LEAF_LIGHT, rough=0.9)
    red = mat('hibiscus_petal', P.HIBISCUS_RED, rough=0.7)
    red_d = mat('hibiscus_throat', '#8E1220', rough=0.7)
    stamen = mat('hibiscus_stamen', P.STAMEN, rough=0.6)
    rng = np.random.RandomState(4)
    for i in range(22):
        az = i * 360 / 22 + rng.uniform(-8, 8)
        e = rng.uniform(15, 70)
        h = rng.uniform(0.12, 0.55)
        ln = rng.uniform(0.3, 0.45)
        m = (leaf_d, leaf_m, leaf_l)[i % 3]
        a.add(blade(ln, 0.17, 0.01, 5, 'leaf', zfun=lambda t, ln=ln: -0.2 * ln * t * t),
              m, 'main', M((0, h, 0), rot=(90 - e, az, 0)), flat=True)
    for (x, y, z, tilt) in ((0.18, 0.78, 0.15, 25), (-0.25, 0.62, 0.1, 40), (0.05, 0.7, -0.3, 30)):
        a.add(segment((x * 0.2, 0.3, z * 0.2), (x, y, z), 0.012, 5), leaf_d, 'main')
        for k in range(5):
            a.add(blade(0.14, 0.075, 0.006, 5, 'petal', zfun=lambda t: 0.03 * t * t), red, 'main',
                  M((x, y, z), rot=(52, k * 72, 0)) @ M(rot=(0, 0, 0)), flat=True)
        a.add(sphere(0.03, 1), red_d, 'main', M((x, y + 0.01, z)))
        a.add(segment((x, y, z), (x + 0.03, y + 0.11, z + 0.02), 0.006, 4), stamen, 'main')
        a.add(sphere(0.014, 1), stamen, 'main', M((x + 0.03, y + 0.115, z + 0.02)))
    return a


def banana_plant():
    """Banana plant, 2.6 m tall, 7 broad leaves."""
    a = Asset('banana_plant')
    stem = mat('banana_stem', '#9CB05A', rough=0.9)
    leaf = mat('banana_leaf', P.LEAF_LIGHT, rough=0.85)
    leaf2 = mat('banana_leaf_dark', P.LEAF_MID, rough=0.85)
    rib = mat('banana_rib', '#D8E08A', rough=0.9)
    a.add(lathe([(0.17, 0), (0.12, 1.1), (0.09, 1.55)], 9), stem, 'main')
    for i in range(7):
        az = i * 360 / 7 + 10
        L = 1.8 + 0.3 * (i % 3)
        zf = lambda t, L=L: L * (0.55 * t * t - 0.2 * t)
        FT = M((0, 1.5, 0), rot=(90, az, 0))
        a.add(blade(L, 0.42, 0.012, 8, 'petal', zfun=zf), leaf if i % 2 else leaf2, 'main', FT, flat=True)
        a.add(blade(L * 0.96, 0.02, 0.016, 8, 'leaf', zfun=lambda t, L=L: zf(t) - 0.012), rib, 'main', FT)
    return a


def _heightfield(w, d, nx, nz, amp, seed, y0=0.0):
    rng = np.random.RandomState(seed)
    xs = np.linspace(-w / 2, w / 2, nx + 1)
    zs = np.linspace(-d / 2, d / 2, nz + 1)
    h = np.zeros((nx + 1, nz + 1))
    for fx, fz, k in ((0.7, 0.9, 1.0), (1.9, 1.3, 0.5), (3.7, 4.1, 0.25)):
        p1, p2 = rng.uniform(0, 6.28, 2)
        X, Z = np.meshgrid(xs, zs, indexing='ij')
        h += k * np.sin(fx * X + p1) * np.sin(fz * Z + p2)
    h = (h / 1.75) * amp + y0
    verts = np.array([[xs[i], h[i, j], zs[j]] for i in range(nx + 1) for j in range(nz + 1)])
    faces = []
    for i in range(nx):
        for j in range(nz):
            p00 = i * (nz + 1) + j
            p01 = p00 + 1
            p10 = (i + 1) * (nz + 1) + j
            p11 = p10 + 1
            faces += [[p00, p01, p10], [p01, p11, p10]]
    m = trimesh.Trimesh(verts, np.array(faces), process=False)
    return m


def _patchy(m, mats, seed=0):
    """Split a mesh into patches by smooth noise on face centres -> list of (mesh, material)."""
    rng = np.random.RandomState(seed)
    p = rng.uniform(0, 6.28, 4)
    c = m.triangles_center
    n = np.sin(0.8 * c[:, 0] + p[0]) + np.sin(0.9 * c[:, 2] + p[1]) + 0.6 * np.sin(2.3 * c[:, 0] + 1.7 * c[:, 2] + p[2])
    bins = np.digitize(n, np.quantile(n, np.linspace(0, 1, len(mats) + 1)[1:-1]))
    out = []
    for k, mt in enumerate(mats):
        sel = bins == k
        part = m.copy()
        part.update_faces(sel)
        part.remove_unreferenced_vertices()
        out.append((part, mt))
    return out


def ground_red_earth():
    """8 x 8 m walkable red-earth tile (top at y=0), with pebbles. Tiles seamlessly along X and Z edges roughly."""
    a = Asset('ground_red_earth')
    e1 = mat('earth_light', P.EARTH_LIGHT, rough=1.0)
    e2 = mat('earth_mid', P.EARTH_MID, rough=1.0)
    e3 = mat('earth_dark', P.EARTH_DARK, rough=1.0)
    pebble = mat('earth_pebble', P.ROCK_MID, rough=1.0)
    hf = _heightfield(8, 8, 16, 16, 0.07, 5)
    for part, mt in _patchy(hf, (e1, e2, e1, e3), 3):
        a.add(part, mt, 'main', flat=True)
    a.add(box((8, 0.5, 8)), e3, 'main', M((0, -0.42, 0)))
    rng = np.random.RandomState(9)
    for i in range(16):
        r = rng.uniform(0.07, 0.2)
        a.add(lumpy(r, 1, 0.3, i, 0.7, -0.4), pebble, 'main', M((rng.uniform(-3.7, 3.7), r * 0.2, rng.uniform(-3.7, 3.7))), flat=True)
    return a


def paddy_field():
    """8 x 8 m paddy tile: wet green field with planted rice rows."""
    a = Asset('paddy_field')
    water = mat('paddy_water', '#9BB86A', rough=0.15, emissive='#C8D890', emissive_strength=0.03)
    mud = mat('paddy_mud', P.EARTH_DARK, rough=1.0)
    g1 = mat('rice_light', P.LEAF_LIGHT, rough=0.85)
    g2 = mat('rice_mid', P.LEAF_MID, rough=0.85)
    hf = _heightfield(8, 8, 8, 8, 0.02, 2, y0=-0.05)
    a.add(hf, water, 'main', flat=True)
    a.add(box((8, 0.4, 8)), mud, 'main', M((0, -0.3, 0)))
    rng = np.random.RandomState(1)
    for i in range(9):
        for j in range(9):
            x = -3.6 + i * 0.9 + rng.uniform(-0.1, 0.1)
            z = -3.6 + j * 0.9 + rng.uniform(-0.1, 0.1)
            for k in range(3):
                az = k * 120 + rng.uniform(-25, 25)
                a.add(blade(0.5, 0.045, 0.006, 3, 'leaf', zfun=lambda t: 0.12 * t * t),
                      g1 if (i + j + k) % 2 else g2, 'main', M((x, -0.05, z), rot=(80, az, 0)), flat=True)
    return a


ENTRIES = [
    ('palm_tree', palm_tree, 25, 12),
    ('hibiscus', hibiscus, 30, 20),
    ('banana_plant', banana_plant, 30, 12),
    ('ground_red_earth', ground_red_earth, 25, 35),
    ('paddy_field', paddy_field, 25, 35),
]
