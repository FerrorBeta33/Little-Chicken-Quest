"""Writes ../manifest.json (sizes, nodes, materials) by reading the finished GLB files."""
import json, os, struct, sys
import trimesh
HERE = os.path.dirname(os.path.abspath(__file__))
MODELS = os.path.join(HERE, '..', 'models')


def lin2hex(l):
    l = max(0.0, min(1.0, l))
    s = 12.92 * l if l <= 0.0031308 else 1.055 * l ** (1 / 2.4) - 0.055
    return round(s * 255)


def read_json(path):
    data = open(path, 'rb').read()
    clen, _ = struct.unpack('<II', data[12:20])
    return json.loads(data[20:20 + clen])


def build():
    out = {}
    for f in sorted(os.listdir(MODELS)):
        if not f.endswith('.glb'):
            continue
        p = os.path.join(MODELS, f)
        j = read_json(p)
        sc = trimesh.load(p, force='scene')
        tris = sum(len(g.faces) for g in sc.geometry.values())
        lo, hi = sc.bounds
        mats = []
        for m in j['materials']:
            r, g, b, a = m['pbrMetallicRoughness']['baseColorFactor']
            mats.append({'name': m['name'], 'hex': '#%02X%02X%02X' % (lin2hex(r), lin2hex(g), lin2hex(b)),
                         'glow': 'emissiveFactor' in m, 'alpha': a})
        groups = []
        for n in j['nodes']:
            if n.get('children'):
                groups.append({'node': n['name'], 'pivot': [round(v, 3) for v in n.get('translation', [0, 0, 0])]})
        out[f[:-4]] = {
            'file': f'assets/models/{f}', 'kb': round(os.path.getsize(p) / 1024), 'triangles': tris,
            'size_m': [round(float(v), 2) for v in (hi - lo)],
            'min_y': round(float(lo[1]), 2), 'max_y': round(float(hi[1]), 2),
            'nodes': groups, 'materials': mats,
        }
    json.dump(out, open(os.path.join(HERE, '..', 'manifest.json'), 'w'), indent=1)
    return out


if __name__ == '__main__':
    m = build()
    print(len(m), 'models,', sum(v['triangles'] for v in m.values()), 'triangles total,', sum(v['kb'] for v in m.values()), 'KB total')
