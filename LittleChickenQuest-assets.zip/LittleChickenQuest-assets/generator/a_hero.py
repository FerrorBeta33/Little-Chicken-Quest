"""Hero chicken, collectible feather, and small props (rocks, clouds, puddle, vine)."""
import math
import numpy as np
from lib import *
import palette as P


def chicken():
    """Tiny round chicken, ~0.62 m tall with comb. Faces +Z. Origin on the ground between the feet.
    Nodes: body, head, wing_L, wing_R, tail, leg_L, leg_R (pivots at the joints, so code can flap/waddle)."""
    a = Asset('chicken')
    cream = mat('chicken_cream', P.CHICKEN_CREAM, rough=0.95)
    amber = mat('chicken_amber', P.CHICKEN_AMBER, rough=0.95)
    comb = mat('chicken_comb', P.CHICKEN_COMB, rough=0.7)
    beak = mat('chicken_beak', P.CHICKEN_BEAK, rough=0.7)
    leg = mat('chicken_leg', P.CHICKEN_LEG, rough=0.8)
    eye = mat('chicken_eye', P.CHICKEN_EYE, rough=0.3)
    shine = mat('chicken_eye_shine', '#FFFFFF', rough=0.2, emissive='#FFFFFF', emissive_strength=0.4)
    bag = mat('bag_teal', P.BAG_TEAL, rough=0.9)
    flap = mat('bag_teal_dark', P.BAG_TEAL_DARK, rough=0.9)
    buckle = mat('bag_buckle_gold', P.GOLD_MID, rough=0.4, metal=0.3)

    # body
    a.part('body', (0, 0, 0))
    a.add(sphere(0.2, 3), cream, 'body', M((0, 0.25, 0), scale=(1.0, 0.96, 1.05)))

    # bag + strap (strap follows the chest surface)
    a.add(box((0.055, 0.085, 0.09)), bag, 'body', M((-0.205, 0.15, 0.03), rot=(0, 0, 8)))
    a.add(box((0.06, 0.03, 0.095)), flap, 'body', M((-0.207, 0.195, 0.03), rot=(0, 0, 8)))
    a.add(box((0.012, 0.016, 0.02)), buckle, 'body', M((-0.236, 0.185, 0.045)))
    c = np.array([0, 0.25, 0.0])
    d0 = np.array([0.55, 0.62, 0.45]); d0 /= np.linalg.norm(d0)       # right shoulder
    d1 = np.array([-0.92, -0.18, 0.2]); d1 /= np.linalg.norm(d1)      # left hip (bag)
    pts = []
    for s in np.linspace(0, 1, 9):
        dv = (1 - s) * d0 + s * d1
        dv = dv / np.linalg.norm(dv)
        # chest bulges: stretch the sphere the same way the body is stretched
        pts.append(c + dv * 0.206 * np.array([1.0, 0.96, 1.05]))
    for p0, p1 in zip(pts[:-1], pts[1:]):
        a.add(segment(p0, p1, 0.011, 5), flap, 'body')

    # head group (pivot at the neck)
    a.part('head', (0, 0.38, 0.05))
    a.add(sphere(0.105, 3), cream, 'head', M((0, 0.46, 0.1)))
    for z, y, s in ((0.15, 0.545, 0.034), (0.11, 0.56, 0.04), (0.07, 0.548, 0.033)):
        a.add(sphere(s, 2), comb, 'head', M((0, y, z), scale=(0.7, 1.15, 0.95)))
    a.add(sphere(0.022, 2), comb, 'head', M((0, 0.395, 0.185), scale=(0.8, 1.3, 0.8)))   # wattle
    beak_m = lathe([(0.038, 0), (0.02, 0.04), (0.0, 0.085)], 8)
    beak_m.apply_transform(M(rot=(90, 0, 0)))                                           # Y -> +Z
    a.add(beak_m, beak, 'head', M((0, 0.44, 0.185)))
    for sx in (-1, 1):
        a.add(sphere(0.0165, 2), eye, 'head', M((sx * 0.058, 0.475, 0.165)))
        a.add(sphere(0.0055, 1), shine, 'head', M((sx * 0.066, 0.482, 0.178)))
        a.add(sphere(0.022, 2), mat('chicken_cheek', '#F4B7A0', rough=0.95), 'head', M((sx * 0.082, 0.435, 0.14), scale=(0.5, 0.9, 0.9)))

    # wings (pivot at the shoulder)
    for side, sx in (('L', 1), ('R', -1)):
        pivot = (sx * 0.17, 0.31, 0.0)
        a.part(f'wing_{side}', pivot)
        a.add(sphere(0.1, 2), amber, f'wing_{side}', M((sx * 0.212, 0.24, -0.01), rot=(0, 0, -sx * 12), scale=(0.3, 0.9, 0.62)))

    # tail fan
    a.part('tail', (0, 0.27, -0.17))
    for ang in (-32, -16, 0, 16, 32):
        a.add(blade(0.24, 0.06, 0.014, 6, 'feather', zfun=lambda t: -0.04 * t * t), amber, 'tail',
              M((0, 0.26, -0.18), rot=(-52, 0, ang)))

    # legs (pivot at the hip)
    for side, sx in (('L', 1), ('R', -1)):
        a.part(f'leg_{side}', (sx * 0.06, 0.1, 0.02))
        a.add(cyl(0.011, 0.1, 6), leg, f'leg_{side}', M((sx * 0.06, 0.05, 0.02)))
        for ang in (-28, 0, 28):
            a.add(box((0.016, 0.014, 0.075)), leg, f'leg_{side}',
                  M((sx * 0.06, 0.008, 0.02), rot=(0, ang, 0)) @ M((0, 0, 0.03)))
    return a


def feather_gold():
    """Glowing golden feather pickup, 0.4 m long, centred on its middle. Nodes: feather, glow (toggle glow.visible)."""
    a = Asset('feather_gold')
    vane = mat('feather_gold', P.GOLD_LIGHT, rough=0.5, emissive='#FFB830', emissive_strength=0.75)
    spine = mat('feather_spine', P.GOLD_MID, rough=0.5, emissive='#FF9A1F', emissive_strength=0.45)
    glow = mat('feather_glow', '#FFC850', rough=1.0, emissive='#FFC850', emissive_strength=1.0, alpha=0.18)
    a.part('feather')
    curve = lambda t: 0.035 * t * t
    a.add(blade(0.38, 0.065, 0.006, 9, 'feather', zfun=curve), vane, 'feather', M((0, -0.2, 0)))
    a.add(blade(0.38, 0.034, 0.012, 9, 'feather', zfun=curve), spine, 'feather', M((0, -0.2, 0.002)))
    a.add(segment((0, -0.26, 0), (0, -0.2, 0), 0.006, 5), spine, 'feather')
    a.part('glow')
    a.add(sphere(0.3, 2), glow, 'glow', M(scale=(0.55, 1.0, 0.55)))
    return a


def rock(seed, size):
    a = Asset(f'rock_{seed}')
    rock_m = mat('rock_body', P.ROCK_MID, rough=1.0)
    rock_l = mat('rock_light', P.ROCK_LIGHT, rough=1.0)
    moss = mat('rock_moss', P.MOSS, rough=1.0)
    m = lumpy(size, 2, 0.28, seed, 0.72, -0.5)
    moss_m, rest = split_faces(m, lambda n, c: n[1] > 0.8)
    rest_light, rest_dark = split_faces(rest, lambda n, c: n[0] + n[2] > 0.3)
    a.add(moss_m, moss, 'main', M((0, size * 0.34, 0)), flat=True)
    a.add(rest_light, rock_l, 'main', M((0, size * 0.34, 0)), flat=True)
    a.add(rest_dark, rock_m, 'main', M((0, size * 0.34, 0)), flat=True)
    return a


def cloud():
    """Soft painterly cloud, ~6 m wide. Lit top + shaded underside."""
    a = Asset('cloud')
    light = mat('cloud_light', P.CLOUD_LIGHT, rough=1.0)
    shade = mat('cloud_shade', P.CLOUD_SHADE, rough=1.0)
    blobs = [((0, 0.7, 0), 1.35), ((-1.4, 0.45, 0.2), 1.05), ((1.5, 0.5, -0.1), 1.15), ((0.5, 1.2, 0.4), 1.0),
             ((-0.8, 1.15, -0.4), 0.95), ((2.6, 0.25, 0.2), 0.8), ((-2.5, 0.2, 0), 0.8), ((0.0, 0.55, 0.9), 0.9),
             ((1.0, 0.35, -0.9), 0.85), ((-1.0, 0.3, -0.8), 0.8), ((0.2, 0.3, 0.2), 1.1)]
    for pos, r in blobs:
        m = sphere(r, 2)
        top, under = split_faces(m, lambda n, c: n[1] > -0.25)
        T = M(pos, scale=(1.0, 0.72, 0.9))
        a.add(top, light, 'main', T)
        a.add(under, shade, 'main', T)
    return a


def puddle():
    """Flat shiny puddle, 1.3 x 0.9 m. Reflects the sky colour."""
    a = Asset('puddle')
    w = mat('puddle_water', P.WATER_GOLD, rough=0.08, emissive='#F0B060', emissive_strength=0.1)
    a.add(cyl(0.5, 0.012, 20), w, 'main', M((0, 0.006, 0), scale=(1.3, 1, 0.9)))
    a.add(torus(0.62, 0.012, 20, 5), mat('puddle_rim', P.EARTH_MID, rough=1.0), 'main', M((0, 0.006, 0), scale=(1.05, 0.6, 0.72)))
    return a


def vine():
    """Hanging forest vine, 3 m long, hangs from its origin straight down (-Y)."""
    a = Asset('vine')
    stem = mat('vine_stem', P.LEAF_DARK, rough=0.9)
    leaf = mat('vine_leaf', P.LEAF_MID, rough=0.9)
    leaf2 = mat('vine_leaf_light', P.LEAF_LIGHT, rough=0.9)
    pts = [np.array([0.12 * math.sin(i * 0.9), -i * 0.25, 0.1 * math.cos(i * 0.7)]) for i in range(13)]
    for p0, p1 in zip(pts[:-1], pts[1:]):
        a.add(segment(p0, p1, 0.022, 5), stem, 'main')
    for i in range(1, 13):
        for k, sx in enumerate((-1, 1)):
            m = leaf if (i + k) % 2 else leaf2
            a.add(blade(0.26, 0.085, 0.008, 4, 'leaf', zfun=lambda t: 0.04 * t),
                  m, 'main', M(pts[i], rot=(0, 20 * sx, 90 + sx * 55 - 90 + 90)) @ M(), flat=True)
    return a
