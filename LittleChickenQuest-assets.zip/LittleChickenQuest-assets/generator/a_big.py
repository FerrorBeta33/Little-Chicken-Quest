"""The three showpiece models: golden lotus chariot, giant stone eagle statue, living rescue eagle."""
import math
import numpy as np
import trimesh
from trimesh.transformations import rotation_matrix
from lib import *
import palette as P


# ------------------------------------------------------------------ helpers
def orient(p, y_axis, z_axis):
    """Matrix placing a blade (length on +Y, thickness on +Z) at p with those world axes."""
    y = np.array(y_axis, float); y /= np.linalg.norm(y)
    z = np.array(z_axis, float); z -= y * np.dot(z, y); z /= np.linalg.norm(z)
    x = np.cross(y, z)
    T = np.eye(4)
    T[:3, 0], T[:3, 1], T[:3, 2], T[:3, 3] = x, y, z, p
    return T


def wing_fan(shoulder, S, width, thick, mats, n=13, rows=3, phi0=22.0, phi1=-62.0,
             row_scale=(1.0, 0.62, 0.36), row_w=(1.0, 0.9, 0.75), stack=0.2, tip_lift=0.5):
    """Right-hand wing built from overlapping flat feathers. Returns [(mesh, material)] in world coords."""
    out = []
    sh = np.array(shoulder, float)
    k = S / 15.0
    for row in range(rows):
        rf = row_scale[row]
        for i in range(n):
            u = i / (n - 1)
            phi = math.radians(phi0 + (phi1 - phi0) * u)
            Li = S * rf * (0.74 + 0.26 * math.sin(math.pi * (0.15 + 0.85 * u)))
            psi = math.degrees(math.atan2(-math.cos(phi), math.sin(phi)))
            d = np.array([math.cos(phi), 0, -math.sin(phi)])
            base = sh + d * (0.9 * k * row) + np.array([0, stack * k * row + 0.012 * S * i / n, 0])
            m = blade(Li, width * row_w[row], thick, 6, 'slab', zfun=lambda t, tl=tip_lift * k: tl * t * t)
            m.apply_transform(M(base, rot=(-90, psi, 0)))
            out.append((m, mats[(i + row) % len(mats)]))
    return out


def toe_paths(ankle, n=4):
    paths = []
    inward = np.array([-1.0, 0.0, 0.1])
    for k in range(n):
        spread = (k - (n - 1) / 2) * 0.55
        d = np.array([0.2, 1.0, spread * 0.5]); d /= np.linalg.norm(d)
        pos = np.array(ankle, float) + np.array([0, 0.2, spread * 0.95])
        pts = [pos.copy()]
        for j in range(4):
            pos = pos + d * (1.15 if j < 3 else 0.85)
            pts.append(pos.copy())
            axis = np.cross(d, inward); axis /= np.linalg.norm(axis)
            d = rotation_matrix(math.radians(44), axis)[:3, :3] @ d
        paths.append((pts, d / np.linalg.norm(d)))
    return paths


# ------------------------------------------------------------------ lotus chariot
def lotus_chariot():
    """Golden lotus-shaped flying chariot (no wheels). Origin = centre of the seat cushion top (put the chicken here).
    3.3 m wide, 6.1 m tall (with hanging ornament and finial), cloth trails 4 m behind. Nodes: base, seat, posts, canopy, cloth, lanterns (canopy pivot = canopy base)."""
    a = Asset('lotus_chariot')
    g_l = mat('chariot_gold_light', P.GOLD_LIGHT, rough=0.32, metal=0.55)
    g_m = mat('chariot_gold', P.GOLD_MID, rough=0.35, metal=0.55)
    g_d = mat('chariot_gold_dark', P.GOLD_DARK, rough=0.4, metal=0.5)
    red = mat('chariot_cushion_red', P.CUSHION_RED, rough=0.9)
    cloth = mat('chariot_cloth', P.CLOTH_CREAM, rough=0.95)
    lamp = mat('chariot_lantern_glow', '#FFD27A', rough=0.5, emissive='#FFB347', emissive_strength=1.0)

    # seat
    a.part('seat')
    a.add(lathe([(1.0, -0.2), (1.08, -0.1), (0.96, 0.0), (0.0, 0.05)], 20), red, 'seat')
    a.add(torus(1.04, 0.045, 28, 6), g_m, 'seat', M((0, -0.08, 0)))

    # base: bowl, two rings of lotus petals, rim, hanging ornament
    a.part('base')
    a.add(lathe([(0.0, -1.3), (0.3, -1.15), (0.6, -0.8), (0.85, -0.45), (0.92, -0.2), (0.0, -0.22)], 20), g_d, 'base')
    for i in range(12):
        az = i * 30
        a.add(blade(1.85, 0.82, 0.05, 7, 'petal', zfun=lambda t: -0.22 * t * t), g_m if i % 2 else g_l, 'base',
              M((0, -1.25, 0), rot=(50, az, 0)), flat=True)
    for i in range(18):
        az = i * 20 + 10
        a.add(blade(0.5, 0.2, 0.03, 4, 'petal', zfun=lambda t: -0.06 * t * t), g_l, 'base',
              M((1.26 * math.cos(math.radians(az)), -0.2, 1.26 * math.sin(math.radians(az))), rot=(-24, 0, 0)) @ M(rot=(0, 0, 0)) if False else
              M((0, -0.2, 0), rot=(0, az, 0)) @ M((0, 0, 1.26), rot=(24, 0, 0)), flat=True)
    a.add(torus(1.42, 0.065, 30, 6), g_d, 'base', M((0, -0.08, 0)))
    a.add(lathe([(0.0, -2.0), (0.1, -1.9), (0.24, -1.65), (0.13, -1.5), (0.32, -1.38), (0.36, -1.22), (0.0, -1.18)], 12), g_l, 'base')

    # posts
    a.part('posts')
    for i in range(6):
        ang = math.radians(i * 60 + 30)
        p0 = np.array([1.32 * math.cos(ang), -0.02, 1.32 * math.sin(ang)])
        p1 = np.array([1.2 * math.cos(ang), 2.0, 1.2 * math.sin(ang)])
        a.add(segment(p0, p1, 0.045, 6), g_m, 'posts')
        a.add(sphere(0.08, 1), g_l, 'posts', M(p0 + np.array([0, 0.5, 0])), flat=True)
    a.add(torus(1.28, 0.03, 28, 5), g_m, 'posts', M((0, 0.75, 0)))

    # canopy
    a.part('canopy', (0, 2.0, 0))
    a.add(lathe([(1.58, 0.0), (1.55, 0.14), (1.25, 0.55), (0.85, 0.9), (0.5, 1.15), (0.22, 1.3), (0.0, 1.35)], 24), g_l, 'canopy', M((0, 2.0, 0)))
    lining = lathe([(1.5, -0.03), (1.15, 0.42), (0.0, 1.05)], 24)
    lining.invert()
    a.add(lining, red, 'canopy', M((0, 2.0, 0)))
    a.add(torus(1.56, 0.06, 30, 6), g_d, 'canopy', M((0, 2.02, 0)))
    for k in range(10):
        ang = math.radians(k * 36)
        a.add(sphere(0.07, 1), g_m, 'canopy', M((1.56 * math.cos(ang), 1.88, 1.56 * math.sin(ang))), flat=True)
    a.add(lathe([(0.0, 0.0), (0.14, 0.05), (0.1, 0.2), (0.2, 0.34), (0.13, 0.55), (0.0, 0.78)], 10), g_l, 'canopy', M((0, 3.32, 0)))

    # flowing cloth (waves in the up/down direction, streams toward -Z)
    a.part('cloth')
    for k, (x, y, L, ph) in enumerate(((-0.7, 2.15, 2.5, 0.0), (0.0, 2.3, 2.9, 1.3), (0.7, 2.15, 2.4, 2.4))):
        wave = lambda t, L=L, ph=ph: 0.28 * math.sin(2 * math.pi * (1.5 * t) + ph) * t + 0.1 * t
        a.add(blade(L, 0.28, 0.008, 14, 'slab', zfun=wave), cloth, 'cloth', M((x, y, -1.25), rot=(-90, 0, 0)))

    # lanterns
    a.part('lanterns')
    for (x, z) in ((1.2, 0.9), (-1.2, 0.9), (1.2, -0.9), (-1.2, -0.9)):
        a.add(segment((x, 2.0, z), (x, 1.5, z), 0.012, 4), g_d, 'lanterns')
        a.add(lathe([(0.0, -0.2), (0.1, -0.12), (0.13, 0.0), (0.1, 0.12), (0.0, 0.2)], 8), g_m, 'lanterns', M((x, 1.3, z)), flat=True)
        a.add(sphere(0.07, 1), lamp, 'lanterns', M((x, 1.3, z)))
    return a


# ------------------------------------------------------------------ giant stone eagle statue
def eagle_statue():
    """Giant reclining stone eagle, wings spread on a rocky hilltop. Origin: ground centre. Wingspan ~39 m,
    head at ~13 m, raised claw at +X, base rock 44 m across. Front faces +Z. Original design (a tribute, not a copy of any statue)."""
    a = Asset('eagle_statue')
    sl = mat('statue_stone_light', P.STONE_LIGHT, rough=1.0)
    sm = mat('statue_stone_mid', P.STONE_MID, rough=1.0)
    sd = mat('statue_stone_dark', P.STONE_DARK, rough=1.0)
    moss = mat('statue_moss', P.MOSS, rough=1.0)
    rock = mat('statue_base_rock', P.ROCK_MID, rough=1.0)
    eye = mat('statue_eye', '#3A2A22', rough=0.6)
    gleam = mat('statue_eye_gleam', '#FFE0A0', rough=0.3, emissive='#FFC060', emissive_strength=0.6)
    cyc = [sl, sm, sd, sm, sl, sm, sd, sl]

    # base rock
    a.part('base')
    br = lumpy(22, 3, 0.1, 5, 0.04, -0.6)
    top, rest = split_faces(br, lambda n, c: n[1] > 0.85)
    rock_l = mat('statue_base_rock_light', P.ROCK_LIGHT, rough=1.0)
    mossy, rocky = split_faces(top, lambda n, c: math.sin(0.28 * c[0]) * math.sin(0.33 * c[2]) > 0.42)
    a.add(rest, rock, 'base', M((0, -0.55, 0)), flat=True)
    a.add(rocky, rock_l, 'base', M((0, -0.55, 0)), flat=True)
    a.add(mossy, moss, 'base', M((0, -0.55, 0)), flat=True)

    # body
    a.part('body')
    ctr = np.array([0, 2.6, -1.5]); rad = np.array([4.3, 2.7, 6.2])
    a.add(sphere(1, 3), sm, 'body', M(ctr, scale=tuple(rad)), flat=True)
    for r, bel in enumerate(np.linspace(52, -22, 6)):
        for c, az in enumerate(np.linspace(-78, 78, 11 - (r % 2))):
            b, aa = math.radians(bel), math.radians(az + (7 if r % 2 else 0))
            p = ctr + np.array([rad[0] * math.sin(aa) * math.cos(b), rad[1] * math.sin(b), rad[2] * math.cos(aa) * math.cos(b)])
            n = (p - ctr) / rad ** 2; n /= np.linalg.norm(n)
            down = np.array([0, -1, 0]) - n * n[1] * -1.0
            down = np.array([0, -1.0, 0]); down = down - n * np.dot(down, n)
            if np.linalg.norm(down) < 1e-6:
                continue
            m = blade(1.9, 0.62, 0.16, 3, 'slab')
            m.apply_transform(orient(p + n * 0.05, down, n))
            a.add(m, cyc[(r * 3 + c) % len(cyc)], 'body', flat=True)

    # neck + head
    a.part('head')
    nsteps = 8
    for i in range(nsteps):
        s0, s1 = i / nsteps, (i + 1) / nsteps
        f = lambda s: (2.5 * (1 - 0.42 * s), 4.0 + 4.7 * s, -0.4 + 3.7 * s)
        r0, y0, z0 = f(s0); r1, y1, z1 = f(s1)
        a.add(lathe([(r0, y0, 0, z0), (r1, y1, 0, z1)], 14), cyc[i % 3], 'head', flat=True)
        if i in (2, 4, 6):
            a.add(torus(r1 + 0.25, 0.38, 22, 6), sl if i != 4 else sd, 'head', M((0, y1, z1), scale=(1.0, 0.8, 1.0)), flat=True)
    hc = (0, 9.2, 3.5)
    a.add(sphere(1.65, 3), sm, 'head', M(hc, scale=(0.9, 1.0, 1.2)), flat=True)
    # upper beak (hooked), pointing +Z with the tip curving down
    ub = lathe([(0.95, 0, 0, 0), (0.78, 0.7, 0, 0.03), (0.52, 1.6, 0, 0.18), (0.3, 2.3, 0, 0.42), (0.14, 2.7, 0, 0.72), (0.0, 2.85, 0, 0.88)], 12)
    ub.apply_transform(M(rot=(90, 0, 0)))
    a.add(ub, sl, 'head', M((0, 9.0, 4.6)), flat=True)
    lb = lathe([(0.75, 0, 0, 0), (0.55, 0.6, 0, 0), (0.3, 1.3, 0, 0.1), (0.0, 1.7, 0, 0.2)], 10)
    lb.apply_transform(M(rot=(90, 0, 0)))
    a.add(lb, sm, 'head', M((0, 8.1, 4.5)), flat=True)
    for sx in (-1, 1):
        a.add(sphere(0.34, 2), eye, 'head', M((sx * 1.2, 9.55, 4.35)), flat=True)
        a.add(sphere(0.1, 1), gleam, 'head', M((sx * 1.34, 9.65, 4.62)))
        a.add(sphere(0.55, 2), sd, 'head', M((sx * 1.15, 10.15, 4.2), scale=(0.55, 0.4, 1.4)), flat=True)

    # wings
    for side in ('R', 'L'):
        a.part(f'wing_{side}', (3.2 if side == 'R' else -3.2, 1.7, 0.0))
    fan = wing_fan((3.2, 1.7, 0.0), 16.5, 2.1, 0.45, cyc, n=14, rows=3, stack=0.24, tip_lift=0.7)
    for m, mt in fan:
        a.add(m, mt, 'wing_R', flat=True)
        a.add(mirror_x(m), mt, 'wing_L', flat=True)

    # raised claw (right side)
    a.part('claw', (6.0, 8.4, 1.6))
    prev = np.array([3.3, 3.3, 0.8])
    for i in range(1, 7):
        s = i / 6
        pt = np.array([3.3 + 2.7 * s, 3.3 + 5.1 * s, 0.8 + 0.8 * s])
        a.add(segment(prev, pt, 1.25 - 0.55 * s, 10), cyc[i % 3], 'claw', flat=True)
        a.add(torus(1.35 - 0.55 * s, 0.3, 18, 6), sl if i % 2 else sd, 'claw', M(pt, rot=(-20, 0, -28)), flat=True)
        prev = pt
    a.add(sphere(0.85, 2), sm, 'claw', M((6.0, 8.4, 1.6)), flat=True)
    for pts, dfin in toe_paths((6.0, 8.6, 1.6)):
        for j, (p0, p1) in enumerate(zip(pts[:-1], pts[1:])):
            a.add(segment(p0, p1, 0.34 - 0.04 * j, 8), cyc[j % 3], 'claw', flat=True)
            a.add(sphere(0.36 - 0.04 * j, 1), sm, 'claw', M(p1), flat=True)
        tal = lathe([(0.24, 0), (0.14, 0.55), (0.0, 1.35)], 8)
        tal.apply_transform(trimesh.geometry.align_vectors([0, 1, 0], dfin))
        a.add(tal, sd, 'claw', M(pts[-1]), flat=True)

    # make the head and claw read bigger and more dramatic
    def grow(part, centre, k):
        c = np.array(centre, float)
        Tn = translation(c) @ np.diag([k, k, k, 1.0]) @ translation(-c)
        for m, _, _ in a.parts[part]['items']:
            m.apply_transform(Tn)
        a.parts[part]['pivot'] = (Tn @ np.append(a.parts[part]['pivot'], 1.0))[:3]
    grow('head', (0, 3.6, 0.3), 1.3)
    grow('claw', (3.3, 3.3, 0.8), 1.2)
    return a


# ------------------------------------------------------------------ living rescue eagle
def eagle_flying():
    """Rescue eagle, ~9 m wingspan, wings raised for a swoop. Origin = body centre. Faces +Z.
    Nodes: body, wing_L, wing_R (pivots at the shoulders: rotate Z to flap), tail, talons."""
    a = Asset('eagle_flying')
    br = mat('eagle_brown', P.EAGLE_BROWN, rough=0.9)
    gd = mat('eagle_gold', P.EAGLE_GOLD, rough=0.8)
    cr = mat('eagle_cream', P.EAGLE_CREAM, rough=0.9)
    bk = mat('eagle_beak', P.CHICKEN_LEG, rough=0.5)
    eye = mat('eagle_eye', '#2A1A12', rough=0.4)

    a.part('body')
    a.add(sphere(1, 3), br, 'body', M(scale=(0.72, 0.66, 1.55)))
    a.add(sphere(0.8, 2), gd, 'body', M((0, -0.12, 0.5), scale=(0.62, 0.5, 1.0)))
    a.add(sphere(0.48, 2), br, 'body', M((0, 0.38, 1.25)))
    a.add(sphere(0.52, 3), cr, 'body', M((0, 0.62, 1.72), scale=(0.88, 0.95, 1.12)))
    hook = lathe([(0.3, 0, 0, 0), (0.2, 0.25, 0, 0.0), (0.1, 0.5, 0, 0.1), (0.0, 0.62, 0, 0.22)], 8)
    hook.apply_transform(M(rot=(90, 0, 0)))
    a.add(hook, bk, 'body', M((0, 0.55, 2.15)), flat=True)
    for sx in (-1, 1):
        a.add(sphere(0.085, 2), eye, 'body', M((sx * 0.42, 0.72, 1.95)))

    a.part('tail', (0, 0, -1.5))
    for i, ang in enumerate(np.linspace(-34, 34, 7)):
        a.add(blade(1.8, 0.28, 0.06, 5, 'slab', zfun=lambda t: -0.12 * t * t), br if i % 2 else gd, 'tail',
              M((0, 0.0, -1.5), rot=(-90, 0, 0)) @ M(rot=(0, 0, ang)), flat=True)

    a.part('talons', (0, -0.55, 0.3))
    for sx in (-1, 1):
        a.add(segment((sx * 0.25, -0.5, 0.2), (sx * 0.25, -0.95, 0.75), 0.1, 6), bk, 'talons')
        for k in (-1, 0, 1):
            tal = lathe([(0.06, 0), (0.0, 0.34)], 6)
            tal.apply_transform(M(rot=(100, 0, 0)))
            a.add(tal, bk, 'talons', M((sx * 0.25 + k * 0.1, -0.95, 0.78)), flat=True)

    for side, sx in (('R', 1), ('L', -1)):
        a.part(f'wing_{side}', (sx * 0.55, 0.25, 0.35))
    sh = (0.55, 0.25, 0.35)
    fan = wing_fan(sh, 3.9, 0.46, 0.1, [br, gd, br, br, gd], n=12, rows=3, phi0=18, phi1=-58, stack=0.1, tip_lift=0.0)
    lift = translation(sh) @ rotation_matrix(math.radians(24), [0, 0, 1]) @ translation(-np.array(sh))
    for m, mt in fan:
        m.apply_transform(lift)
        a.add(m, mt, 'wing_R', flat=True)
        a.add(mirror_x(m), mt, 'wing_L', flat=True)
    return a


def translation(v):
    T = np.eye(4)
    T[:3, 3] = v
    return T


ENTRIES = [
    ('lotus_chariot', lotus_chariot, 28, 14),
    ('eagle_statue', eagle_statue, 22, 24),
    ('eagle_flying', eagle_flying, 30, 20),
]
