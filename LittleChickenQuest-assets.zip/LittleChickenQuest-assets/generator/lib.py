"""Tiny low-poly model toolkit: builds named, coloured GLB files with trimesh.

Conventions (glTF / three.js): Y is up, +Z is the front of every model, units are metres.
Every material has a stable name (for example chicken_cream) so it can be recoloured in code.
"""
import math
import numpy as np
import trimesh
from trimesh.transformations import euler_matrix, translation_matrix
from trimesh.visual.material import PBRMaterial


# ---------------------------------------------------------------- materials
HEXMAP = {}   # material name -> (base hex, alpha, emissive hex or None, emissive strength)


def srgb_to_linear(c):
    c = c / 255.0
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def hexrgb(h):
    h = h.lstrip('#')
    return [int(h[i:i + 2], 16) for i in (0, 2, 4)]


def mat(name, color, rough=0.85, metal=0.0, emissive=None, emissive_strength=1.0, alpha=1.0):
    m = PBRMaterial(
        name=name,
        baseColorFactor=[*hexrgb(color), int(round(alpha * 255))],
        metallicFactor=metal,
        roughnessFactor=rough,
    )
    if emissive:
        m.emissiveFactor = [min(1.0, c / 255.0 * emissive_strength) for c in hexrgb(emissive)]
    if alpha < 1.0:
        m.alphaMode = 'BLEND'
    HEXMAP[name] = (color, alpha, emissive, emissive_strength)
    return m


def _patch_glb(data):
    """glTF colours are LINEAR. Rewrite every material with exact float linear values (from the sRGB hex)."""
    import json
    import struct
    off = 12
    chunks = []
    while off < len(data):
        clen, ctype = struct.unpack('<II', data[off:off + 8])
        chunks.append([ctype, data[off + 8:off + 8 + clen]])
        off += 8 + clen
    j = json.loads(chunks[0][1].decode('utf-8'))
    for m in j.get('materials', []):
        info = HEXMAP.get(m.get('name'))
        if not info:
            continue
        color, alpha, emissive, strength = info
        r, g, b = [srgb_to_linear(c) for c in hexrgb(color)]
        m.setdefault('pbrMetallicRoughness', {})['baseColorFactor'] = [round(r, 5), round(g, 5), round(b, 5), alpha]
        if emissive:
            er, eg, eb = [srgb_to_linear(c) for c in hexrgb(emissive)]
            m['emissiveFactor'] = [round(min(1.0, er * strength), 5), round(min(1.0, eg * strength), 5), round(min(1.0, eb * strength), 5)]
        m['doubleSided'] = False
    body = json.dumps(j, separators=(',', ':')).encode('utf-8')
    body += b' ' * ((4 - len(body) % 4) % 4)
    chunks[0][1] = body
    out = b''.join(struct.pack('<II', len(c), t) + c for t, c in chunks)
    return struct.pack('<III', 0x46546C67, 2, 12 + len(out)) + out


# ---------------------------------------------------------------- transforms
def M(pos=(0, 0, 0), rot=(0, 0, 0), scale=(1, 1, 1)):
    """4x4 matrix: scale, then rotate (degrees, X then Y then Z about fixed axes), then move."""
    if np.isscalar(scale):
        scale = (scale, scale, scale)
    S = np.diag([scale[0], scale[1], scale[2], 1.0])
    R = euler_matrix(*np.radians(rot), 'sxyz')
    return translation_matrix(pos) @ R @ S


# ---------------------------------------------------------------- primitives (Y up)
def sphere(r=1.0, subdiv=2):
    return trimesh.creation.icosphere(subdivisions=subdiv, radius=r)


def box(ex):
    return trimesh.creation.box(extents=ex)


def cyl(r, h, sections=12):
    """Cylinder standing on Y, centred on the origin."""
    m = trimesh.creation.cylinder(radius=r, height=h, sections=sections)
    m.apply_transform(euler_matrix(-math.pi / 2, 0, 0, 'sxyz'))
    return m


def lathe(profile, sections=16):
    """Surface of revolution around Y. profile = [(radius, y)] or [(radius, y, cx, cz)] bottom to top."""
    prof = [tuple(p) + (0.0, 0.0) * (1 if len(p) == 2 else 0) for p in profile]
    prof = [(p[0], p[1], p[2] if len(p) > 2 else 0.0, p[3] if len(p) > 3 else 0.0) for p in prof]
    n = len(prof)
    ang = np.linspace(0, 2 * np.pi, sections, endpoint=False)
    verts, faces = [], []
    for r, y, cx, cz in prof:
        for a in ang:
            verts.append([cx + r * math.cos(a), y, cz + r * math.sin(a)])
    for i in range(n - 1):
        for j in range(sections):
            a = i * sections + j
            b = i * sections + (j + 1) % sections
            c = (i + 1) * sections + j
            d = (i + 1) * sections + (j + 1) % sections
            faces += [[a, c, b], [b, c, d]]
    if prof[0][0] > 1e-6:
        verts.append([prof[0][2], prof[0][1], prof[0][3]])
        ci = len(verts) - 1
        for j in range(sections):
            faces.append([ci, j, (j + 1) % sections])
    if prof[-1][0] > 1e-6:
        verts.append([prof[-1][2], prof[-1][1], prof[-1][3]])
        ci = len(verts) - 1
        base = (n - 1) * sections
        for j in range(sections):
            faces.append([ci, base + (j + 1) % sections, base + j])
    m = trimesh.Trimesh(np.array(verts), np.array(faces), process=False)
    m.update_faces(m.nondegenerate_faces())
    m.remove_unreferenced_vertices()
    return m


def torus(R, r, seg_u=24, seg_v=8):
    verts, faces = [], []
    for i in range(seg_u):
        u = 2 * math.pi * i / seg_u
        for j in range(seg_v):
            v = 2 * math.pi * j / seg_v
            verts.append([(R + r * math.cos(v)) * math.cos(u), r * math.sin(v), (R + r * math.cos(v)) * math.sin(u)])
    for i in range(seg_u):
        for j in range(seg_v):
            a = i * seg_v + j
            b = i * seg_v + (j + 1) % seg_v
            c = ((i + 1) % seg_u) * seg_v + j
            d = ((i + 1) % seg_u) * seg_v + (j + 1) % seg_v
            faces += [[a, b, c], [b, d, c]]
    m = trimesh.Trimesh(np.array(verts), np.array(faces), process=False)
    _orient_outward(m, lambda p: np.array([R * p[0] / max(1e-9, math.hypot(p[0], p[2])), 0,
                                           R * p[2] / max(1e-9, math.hypot(p[0], p[2]))]))
    return m


def _orient_outward(m, centre_fn):
    """Flip any face whose normal points toward the local centre line."""
    tri = m.vertices[m.faces]
    centres = tri.mean(axis=1)
    normals = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
    flip = np.array([np.dot(normals[k], centres[k] - centre_fn(centres[k])) < 0 for k in range(len(centres))])
    m.faces[flip] = m.faces[flip][:, ::-1]


def blade(length, width, thick=0.02, segs=8, profile='leaf', zfun=None, xfun=None):
    """Flat tapered blade (leaf, petal, feather, slab). Runs along +Y, width on X, thickness on Z.
    zfun(t)/xfun(t) give bend / sideways offset in metres at t in 0..1 along the length."""
    ts = np.linspace(0, 1, segs + 1)

    def wprof(t):
        if profile == 'leaf':
            return math.sin(math.pi * min(1.0, max(0.0, t))) ** 0.7
        if profile == 'feather':
            return (1 - t ** 2.2) ** 0.8 * (0.35 + 0.65 * min(1.0, t * 6))
        if profile == 'slab':
            return 1.0 if t < 0.82 else math.sqrt(max(0.0, 1 - ((t - 0.82) / 0.18) ** 2))
        if profile == 'petal':
            return math.sin(math.pi * (0.12 + 0.88 * t)) ** 0.5 * (1 - 0.15 * t)
        return 1.0

    verts, ring_idx = [], []
    for t in ts:
        w = width * wprof(t)
        th = thick * (1.0 - 0.6 * t)
        cz = zfun(t) if zfun else 0.0
        cx = xfun(t) if xfun else 0.0
        y = t * length
        if w < 1e-6 or (t >= 1.0 and profile != 'slab'):
            verts.append([cx, y, cz])
            ring_idx.append([len(verts) - 1] * 4)
        else:
            base = len(verts)
            verts += [[cx - w, y, cz], [cx, y, cz + th], [cx + w, y, cz], [cx, y, cz - th]]
            ring_idx.append([base, base + 1, base + 2, base + 3])
    faces = []
    for k in range(segs):
        r0, r1 = ring_idx[k], ring_idx[k + 1]
        for e in range(4):
            a, b = r0[e], r0[(e + 1) % 4]
            c, d = r1[e], r1[(e + 1) % 4]
            for tri in ([a, b, d], [a, d, c]):
                if len(set(tri)) == 3:
                    faces.append(tri)
    for ring in (ring_idx[0], ring_idx[-1]):
        if len(set(ring)) == 4:
            faces += [[ring[0], ring[1], ring[2]], [ring[0], ring[2], ring[3]]]
    m = trimesh.Trimesh(np.array(verts, float), np.array(faces), process=False)

    def centre(p):
        t = min(1.0, max(0.0, p[1] / max(1e-9, length)))
        return np.array([xfun(t) if xfun else 0.0, p[1], zfun(t) if zfun else 0.0])

    _orient_outward(m, centre)
    return m


def segment(p0, p1, thickness=0.02, sections=6):
    """Thin round bar between two points."""
    p0, p1 = np.array(p0, float), np.array(p1, float)
    d = p1 - p0
    length = float(np.linalg.norm(d))
    if length < 1e-9:
        return trimesh.Trimesh()
    m = cyl(thickness, length, sections)
    A = trimesh.geometry.align_vectors([0, 1, 0], d / length)
    m.apply_transform(A)
    m.apply_translation((p0 + p1) / 2)
    return m


def lumpy(r=1.0, subdiv=2, amp=0.25, seed=0, squash=0.7, flat_floor=-0.45):
    """Rock-like lump. Returns mesh with merged vertices (so displacement is continuous)."""
    rng = np.random.RandomState(seed)
    p = rng.uniform(0, 6.28, 6)
    m = trimesh.creation.icosphere(subdivisions=subdiv, radius=1.0)
    v = m.vertices.copy()
    n = (0.5 * np.sin(1.7 * v[:, 0] + p[0]) + 0.3 * np.sin(2.3 * v[:, 1] + p[1]) + 0.2 * np.sin(2.9 * v[:, 2] + p[2])
         + 0.25 * np.sin(4.1 * v[:, 0] + 3.3 * v[:, 2] + p[3]))
    v = v * (1 + amp * n)[:, None]
    v[:, 1] *= squash
    v[:, 1] = np.maximum(v[:, 1], flat_floor * squash)
    m.vertices = v * r
    return m


def split_faces(m, predicate):
    """Return (selected, rest) copies of a mesh using a predicate on face normals/centres."""
    normals = m.face_normals
    centres = m.triangles_center
    sel = np.array([predicate(normals[i], centres[i]) for i in range(len(m.faces))], bool)
    a, b = m.copy(), m.copy()
    a.update_faces(sel)
    a.remove_unreferenced_vertices()
    b.update_faces(~sel)
    b.remove_unreferenced_vertices()
    return a, b


def mirror_x(m):
    m = m.copy()
    m.vertices = m.vertices * np.array([-1, 1, 1])
    m.faces = m.faces[:, ::-1]
    return m


# ---------------------------------------------------------------- asset container + export
class Asset:
    """Collects meshes under named parts (nodes). A part's pivot is its node origin, so code can rotate it."""

    def __init__(self, name):
        self.name = name
        self.parts = {}
        self.materials = {}

    def part(self, name, pivot=(0, 0, 0)):
        self.parts.setdefault(name, {'pivot': np.array(pivot, float), 'items': []})
        self.parts[name]['pivot'] = np.array(pivot, float)
        return name

    def add(self, mesh, material, part='main', T=None, flat=False):
        if mesh is None or len(mesh.faces) == 0:
            return
        if part not in self.parts:
            self.part(part)
        m = mesh.copy()
        if T is not None:
            m.apply_transform(T)
        self.materials[material.name] = material
        self.parts[part]['items'].append((m, material.name, flat))

    def stats(self):
        tris = sum(len(m.faces) for p in self.parts.values() for m, _, _ in p['items'])
        return tris

    def export(self, path):
        scene = trimesh.Scene()
        for pname, p in self.parts.items():
            pivot = p['pivot']
            scene.graph.update(frame_to=pname, frame_from=scene.graph.base_frame,
                               matrix=translation_matrix(pivot))
            groups = {}
            for m, matname, flat in p['items']:
                groups.setdefault((matname, flat), []).append(m)
            for (matname, flat), meshes in groups.items():
                merged = trimesh.util.concatenate(meshes)
                merged.apply_translation(-pivot)
                if flat:
                    merged.unmerge_vertices()
                _ = merged.vertex_normals   # compute + cache so the GLB carries NORMAL data
                merged.visual = trimesh.visual.TextureVisuals(material=self.materials[matname])
                gname = f'{pname}__{matname}' + ('_flat' if flat else '')
                scene.add_geometry(merged, node_name=gname, geom_name=gname, parent_node_name=pname)
        data = _patch_glb(scene.export(file_type='glb', include_normals=True))
        with open(path, 'wb') as f:
            f.write(data)
        return len(data)
