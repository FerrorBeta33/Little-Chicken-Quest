"""Village hut, temple and mossy stone steps."""
import math
import numpy as np
import trimesh
from lib import *
import palette as P


def tri_prism(base, height, length):
    """Gable-end prism: triangle (base along Z, apex up) extruded along X (length). Centred on X, base at y=0."""
    hb, hl = base / 2, length / 2
    v = [[-hl, 0, -hb], [-hl, 0, hb], [-hl, height, 0], [hl, 0, -hb], [hl, 0, hb], [hl, height, 0]]
    f = [[0, 2, 1], [3, 4, 5], [0, 1, 4], [0, 4, 3], [1, 2, 5], [1, 5, 4], [2, 0, 3], [2, 3, 5]]
    m = trimesh.Trimesh(np.array(v, float), np.array(f), process=False)
    c = m.vertices.mean(axis=0)
    tri = m.vertices[m.faces]
    nrm = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
    flip = np.einsum('ij,ij->i', nrm, tri.mean(axis=1) - c) < 0
    m.faces[flip] = m.faces[flip][:, ::-1]
    return m


def hut_village():
    """Kerala-style village house, 7.4 m wide (X), 7.6 m deep (Z), 5 m tall. Front (veranda) faces +Z."""
    a = Asset('hut_village')
    wall = mat('hut_wall_white', P.WALL_WHITE, rough=0.95)
    plinth = mat('hut_plinth_stone', P.ROCK_MID, rough=1.0)
    plinth_l = mat('hut_step_stone', P.ROCK_LIGHT, rough=1.0)
    wood = mat('hut_wood_dark', P.WOOD_DARK, rough=0.85)
    wood_m = mat('hut_wood_mid', P.WOOD_MID, rough=0.85)
    ta = mat('hut_tile_a', P.ROOF_TILE_A, rough=0.9)
    tb = mat('hut_tile_b', P.ROOF_TILE_B, rough=0.9)
    gold = mat('hut_brass', P.GOLD_MID, rough=0.35, metal=0.4)
    flame = mat('hut_flame', '#FFD27A', rough=0.5, emissive='#FFB347', emissive_strength=1.0)
    pot = mat('hut_clay_pot', P.CLAY_POT, rough=0.95)
    jas = mat('hut_jasmine', '#F8F2CC', rough=0.9)
    jas2 = mat('hut_jasmine_leaf', P.LEAF_MID, rough=0.9)

    a.add(box((6.8, 0.4, 6.6)), plinth, 'main', M((0, 0.2, 0.7)))
    a.add(box((2.2, 0.2, 0.7)), plinth_l, 'main', M((0, 0.1, 4.35)))
    a.add(box((6.0, 2.55, 4.6)), wall, 'main', M((0, 0.4 + 1.275, 0)))
    # door + windows (front, +Z face at z=2.3)
    a.add(box((1.1, 1.95, 0.14)), wood, 'main', M((-0.9, 0.4 + 0.975, 2.34)))
    a.add(box((1.3, 2.15, 0.1)), wood_m, 'main', M((-0.9, 0.4 + 1.075, 2.31)))
    a.add(box((0.95, 0.85, 0.14)), wood, 'main', M((1.8, 2.0, 2.34)))
    a.add(box((1.15, 1.05, 0.1)), wood_m, 'main', M((1.8, 2.0, 2.31)))
    # gable ends
    for sx in (-1, 1):
        a.add(tri_prism(7.4, 1.9, 0.2), wall, 'main', M((sx * 2.9, 3.0, 0.6)))
    # pillars + front beam
    for x in (-2.7, -0.9, 0.9, 2.7):
        a.add(cyl(0.14, 2.62, 8), wood, 'main', M((x, 0.4 + 1.31, 3.4)))
        a.add(box((0.34, 0.12, 0.34)), wood_m, 'main', M((x, 0.4 + 2.66, 3.4)))
        a.add(box((0.3, 0.1, 0.3)), wood_m, 'main', M((x, 0.45, 3.4)))
    a.add(box((7.0, 0.22, 0.24)), wood, 'main', M((0, 3.1, 3.4)))
    # roof: tile rows on both slopes
    alpha = math.radians(28)
    z0, eave_y, half = 0.6, 3.0, 3.7
    slope_len = half / math.cos(alpha)
    rows = 12
    rl = slope_len / rows
    for side in (1, -1):
        for r in range(rows):
            u = (r + 0.5) * rl
            z = z0 + side * (half - u * math.cos(alpha))
            y = eave_y + u * math.sin(alpha)
            a.add(box((7.5, 0.11, rl * 1.02)), ta if r % 2 == 0 else tb, 'main',
                  M((0, y, z), rot=(side * math.degrees(alpha), 0, 0)))
    ridge_y = eave_y + half * math.tan(alpha)
    a.add(box((7.7, 0.18, 0.34)), tb, 'main', M((0, ridge_y + 0.08, z0)))
    # garlands
    for gx in (-3.2, -2.8):
        for k in range(6):
            a.add(sphere(0.07, 1), jas if k % 2 == 0 else jas2, 'main', M((gx, 3.0 - k * 0.15, 3.6)), flat=True)
    # brass lamp, clay pot
    a.add(lathe([(0.2, 0), (0.12, 0.1), (0.06, 0.28), (0.2, 0.34), (0.22, 0.4), (0.0, 0.42)], 10), gold, 'main', M((-2.3, 0.4, 3.9)))
    a.add(sphere(0.045, 1), flame, 'main', M((-2.3, 0.86, 3.9), scale=(0.8, 1.4, 0.8)))
    a.add(lathe([(0.12, 0), (0.3, 0.25), (0.36, 0.45), (0.2, 0.72), (0.23, 0.78), (0.17, 0.78)], 10), pot, 'main', M((1.9, 0.4, 3.9)))
    return a


def temple():
    """Small stone temple: gopuram tower (13 m) behind a pillared hall with a glowing doorway. Front +Z."""
    a = Asset('temple')
    cream = mat('temple_cream', P.TEMPLE_CREAM, rough=0.95)
    ochre = mat('temple_ochre', P.TEMPLE_OCHRE, rough=0.95)
    red = mat('temple_red', P.TEMPLE_RED, rough=0.9)
    gold = mat('temple_gold', P.GOLD_MID, rough=0.35, metal=0.4)
    dark = mat('temple_dark', P.WOOD_DARK, rough=0.9)
    glow = mat('temple_glow', '#FFD27A', rough=0.6, emissive='#FFB347', emissive_strength=1.0)
    stone = mat('temple_stone', P.ROCK_MID, rough=1.0)

    a.add(box((15, 0.6, 16)), stone, 'main', M((0, 0.3, 0)))
    a.add(box((4.5, 0.3, 1.2)), stone, 'main', M((0, 0.15, 8.6)))
    a.add(box((3.6, 0.3, 0.9)), stone, 'main', M((0, 0.3, 8.15)))
    # gopuram tiers
    y = 0.6
    for i in range(5):
        w, d, h = 7.0 - 1.05 * i, 5.0 - 0.7 * i, 1.9 - 0.12 * i
        a.add(box((w, h, d)), cream if i % 2 == 0 else ochre, 'main', M((0, y + h / 2, -3.2)))
        for k in range(3 if i < 4 else 1):
            xk = (k - 1) * (w / 3.4) if i < 4 else 0
            a.add(box((0.55 - 0.04 * i, h * 0.5, 0.12)), dark, 'main', M((xk, y + h * 0.5, -3.2 + d / 2 + 0.04)))
        a.add(box((w + 0.5, 0.26, d + 0.5)), red, 'main', M((0, y + h + 0.13, -3.2)))
        for sx in (-1, 1):
            for sz in (-1, 1):
                a.add(sphere(0.2, 1), gold, 'main', M((sx * (w / 2 + 0.1), y + h + 0.4, -3.2 + sz * (d / 2 + 0.1))), flat=True)
        y += h + 0.26
    top_w = 7.0 - 1.05 * 5
    a.add(cyl(1.25, top_w + 0.6, 14), cream, 'main', M((0, y + 0.55, -3.2), rot=(0, 0, 90), scale=(0.6, 1.0, 1.0)))
    for x in (-1.1, 0, 1.1):
        a.add(lathe([(0.0, 0), (0.28, 0.05), (0.18, 0.35), (0.1, 0.7), (0.15, 0.85), (0.0, 1.2)], 8), gold, 'main', M((x, y + 1.15, -3.2)))
    # front hall
    a.add(box((9, 3.4, 6)), cream, 'main', M((0, 0.6 + 1.7, 3.6)))
    a.add(box((9.6, 0.3, 6.6)), red, 'main', M((0, 0.6 + 3.55, 3.6)))
    roof = lathe([(7.4, 0), (0.0, 2.2)], 4)
    roof.apply_transform(M(rot=(0, 45, 0), scale=(0.78, 1.0, 0.55)))
    a.add(roof, red, 'main', M((0, 0.6 + 3.7, 3.6)))
    a.add(box((2.0, 2.5, 0.14)), glow, 'main', M((0, 0.6 + 1.25, 6.66)))
    a.add(box((2.4, 2.8, 0.12)), dark, 'main', M((0, 0.6 + 1.4, 6.62)))
    for x in (-4.2, -2.6, 2.6, 4.2):
        a.add(cyl(0.22, 3.3, 8), ochre, 'main', M((x, 0.6 + 1.65, 6.9)))
        a.add(box((0.6, 0.18, 0.6)), cream, 'main', M((x, 0.6 + 3.3, 6.9)))
    a.add(box((9.6, 0.25, 0.6)), red, 'main', M((0, 0.6 + 3.45, 6.9)))
    return a


def stone_steps():
    """Nine mossy stone slabs climbing toward -Z, each 0.28 m higher. 8.6 m long, 2.8 m wide."""
    a = Asset('stone_steps')
    s1 = mat('step_stone_light', P.ROCK_LIGHT, rough=1.0)
    s2 = mat('step_stone_mid', P.ROCK_MID, rough=1.0)
    moss = mat('step_moss', P.MOSS, rough=1.0)
    rng = np.random.RandomState(7)
    for i in range(9):
        w = 2.4 + rng.uniform(-0.2, 0.4)
        T = M((rng.uniform(-0.15, 0.15), i * 0.28 + 0.14, -i * 0.82), rot=(0, rng.uniform(-5, 5), rng.uniform(-1.2, 1.2)))
        a.add(box((w, 0.3, 0.95)), s1 if i % 2 else s2, 'main', T, flat=True)
        if i % 3 != 1:
            a.add(box((w * 0.5, 0.04, 0.4)), moss, 'main', T @ M((rng.uniform(-0.5, 0.5), 0.15, rng.uniform(-0.2, 0.2))), flat=True)
    return a


ENTRIES = [
    ('hut_village', hut_village, 30, 22),
    ('temple', temple, 30, 18),
    ('stone_steps', stone_steps, 40, 25),
]
